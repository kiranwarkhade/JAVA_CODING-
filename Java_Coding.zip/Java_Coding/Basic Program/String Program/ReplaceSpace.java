public class ReplaceSpace  {
    
    public static void main(String[] args) {    
        String string = "Hello im a Kiran";    
        char ch = '-';    
            
           
        string = string.replace(' ', ch);    
            
        System.out.println("String after replacing spaces with given character: ");    
        System.out.println(string);    
    }  
}
