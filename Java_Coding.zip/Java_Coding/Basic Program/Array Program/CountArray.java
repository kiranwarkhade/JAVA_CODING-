public class CountArray {
    
    public static void main(String[] args) {  
         
          int [] arr = new int [] {1, 2, 3, 4, 5};  
  
          System.out.println("Number of elements present in given array: " + arr.length);  
      }  
}
