public interface StrLengthInt {
    
    int GetLength(String str);
}
