public interface sumInt {
public abstract  int sum(int a, int b);
 
}
