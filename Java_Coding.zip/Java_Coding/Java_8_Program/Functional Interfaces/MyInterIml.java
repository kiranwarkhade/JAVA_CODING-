public class MyInterIml implements MyInter {

    
    public void sayHello() {
       
       System.out.println("Hello how are you"); 
    }
    
}
