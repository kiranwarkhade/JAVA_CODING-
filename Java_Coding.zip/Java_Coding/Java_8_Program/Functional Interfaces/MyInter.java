@FunctionalInterface
public interface MyInter {
    
    public void sayHello();
   
}
