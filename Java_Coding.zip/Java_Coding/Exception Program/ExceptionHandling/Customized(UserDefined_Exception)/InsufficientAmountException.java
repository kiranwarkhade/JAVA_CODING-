public class InsufficientAmountException extends Exception
{
    
    InsufficientAmountException(String s)
    {
        super(s);
    }
    
}
