package Exception;

import java.util.Scanner;

public class NUllPointerException {

	

	public static void main(String[] ar) {
		
      	int i=(Integer) null;	
//       String s=null;
//       System.out.println(s.length());
	
//		Scanner sc=null;
//		sc.nextInt();
		
	}

}
