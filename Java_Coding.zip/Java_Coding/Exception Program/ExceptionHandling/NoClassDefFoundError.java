package Exception;

public class NoClassDefFoundError {

	public static void main(String[] args) {
		
		//MyClass class=new MyClass();
        //class.info();
	}

}
